<?php

namespace Tests\Feature;

use App\Models\Appointment;
use App\Models\ClinicalNote;
use App\Models\ClinicalRecord;
use App\Models\TreatmentPlan;
use App\Models\TreatmentPlanStage;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class TreatmentPlanWorkflowTest extends TestCase
{
    use RefreshDatabase;

    public function test_psychologist_can_create_a_treatment_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $response = $this->actingAs($psychologist)->post(
            route('psychologist.treatment-plans.store', [
                'clinicalRecord' => $record,
            ]),
            [
                'title' => 'نقشه درمان اضطراب',
                'main_problem' => 'اضطراب و نگرانی مداوم',
            ],
        );

        $response
            ->assertRedirect(
                route('psychologist.clinical-records.show', $client),
            )
            ->assertSessionHas('status');

        $plan = TreatmentPlan::query()->sole();

        $this->assertSame($psychologist->id, $plan->psychologist_id);
        $this->assertSame($client->id, $plan->client_id);
        $this->assertSame($record->id, $plan->clinical_record_id);
        $this->assertSame('نقشه درمان اضطراب', $plan->title);
        $this->assertSame(TreatmentPlan::STATUS_ACTIVE, $plan->status);
        $this->assertSame($client->id, $plan->active_plan_guard);

        $this->assertSame(
            [1, 2, 3],
            TreatmentPlanStage::query()
                ->where('treatment_plan_id', $plan->id)
                ->orderBy('stage_number')
                ->pluck('stage_number')
                ->map(static fn ($value): int => (int) $value)
                ->all(),
        );
    }

    public function test_second_active_plan_for_same_psychologist_and_client_is_rejected(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $firstPlan = $this->createPlan(
            $psychologist,
            $client,
            $record,
        );

        $response = $this->actingAs($psychologist)->post(
            route('psychologist.treatment-plans.store', [
                'clinicalRecord' => $record,
            ]),
            [
                'title' => 'نقشه درمان دوم',
                'main_problem' => 'تلاش برای ایجاد نقشه موازی',
            ],
        );

        $response->assertSessionHasErrors();

        $this->assertDatabaseCount('treatment_plans', 1);
        $this->assertDatabaseHas('treatment_plans', [
            'id' => $firstPlan->id,
            'status' => TreatmentPlan::STATUS_ACTIVE,
        ]);
    }

    public function test_database_guard_rejects_duplicate_active_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $this->createPlan($psychologist, $client, $record);

        $this->expectException(\Illuminate\Database\QueryException::class);

        DB::table('treatment_plans')->insert([
            'psychologist_id' => $psychologist->id,
            'client_id' => $client->id,
            'clinical_record_id' => $record->id,
            'title' => 'نقشه تکراری',
            'main_problem' => null,
            'status' => TreatmentPlan::STATUS_ACTIVE,
            'active_plan_guard' => $client->id,
            'current_stage' => TreatmentPlan::STAGE_ROOT_CAUSE,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function test_treatment_plan_update_requires_three_stages(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);

        $response = $this->actingAs($psychologist)->put(
            route('psychologist.treatment-plans.update', [
                'treatmentPlan' => $plan,
            ]),
            [
                'title' => 'نقشه به‌روزشده',
                'main_problem' => 'مسئله به‌روزشده',
                'current_stage' => TreatmentPlan::STAGE_SKILLS_AND_ACTION,
                'stages' => [
                    1 => [
                        'goal' => 'هدف مرحله اول',
                        'estimated_sessions' => 4,
                    ],
                    2 => [
                        'goal' => 'هدف مرحله دوم',
                        'estimated_sessions' => 6,
                    ],
                ],
            ],
        );

        $response
            ->assertSessionHasErrors([
                'stages',
                'stages.3',
            ]);
    }

    public function test_psychologist_can_update_plan_and_all_three_stages(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $this->createStages($plan);

        $response = $this->actingAs($psychologist)->put(
            route('psychologist.treatment-plans.update', [
                'treatmentPlan' => $plan,
            ]),
            $this->planUpdatePayload(),
        );

        $response
            ->assertRedirect(
                route('psychologist.clinical-records.show', $client),
            )
            ->assertSessionHas('status');

        $this->assertDatabaseHas('treatment_plans', [
            'id' => $plan->id,
            'title' => 'عنوان به‌روزشده',
            'main_problem' => 'مسئله به‌روزشده',
            'current_stage' => TreatmentPlan::STAGE_STABILIZATION,
        ]);

        foreach ([1, 2, 3] as $stageNumber) {
            $this->assertDatabaseHas('treatment_plan_stages', [
                'treatment_plan_id' => $plan->id,
                'stage_number' => $stageNumber,
                'goal' => "هدف به‌روزشده مرحله {$stageNumber}",
                'estimated_sessions' => $stageNumber + 3,
            ]);
        }
    }

    public function test_archive_requires_a_valid_status_and_reason(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);

        $response = $this->actingAs($psychologist)->patch(
            route('psychologist.treatment-plans.archive', [
                'treatmentPlan' => $plan,
            ]),
            [
                'status' => 'invalid-status',
                'status_reason' => '',
            ],
        );

        $response->assertSessionHasErrors([
            'status',
            'status_reason',
        ]);

        $this->assertSame(
            TreatmentPlan::STATUS_ACTIVE,
            $plan->fresh()->status,
        );
    }

    public function test_archiving_plan_releases_active_plan_guard(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);

        $response = $this->actingAs($psychologist)->patch(
            route('psychologist.treatment-plans.archive', [
                'treatmentPlan' => $plan,
            ]),
            [
                'status' => TreatmentPlan::STATUS_COMPLETED,
                'status_reason' => 'اهداف درمان تکمیل شد.',
            ],
        );

        $response
            ->assertRedirect(
                route('psychologist.clinical-records.show', $client),
            )
            ->assertSessionHas('status');

        $this->assertDatabaseHas('treatment_plans', [
            'id' => $plan->id,
            'status' => TreatmentPlan::STATUS_COMPLETED,
            'status_reason' => 'اهداف درمان تکمیل شد.',
            'active_plan_guard' => null,
        ]);
    }

    public function test_another_psychologist_cannot_edit_the_plan(): void
    {
        [$owner, $client, $record] = $this->clinicalContext();
        $otherPsychologist = User::factory()->psychologist()->create();
        $plan = $this->createPlan($owner, $client, $record);

        $response = $this->actingAs($otherPsychologist)->get(
            route('psychologist.treatment-plans.edit', [
                'treatmentPlan' => $plan,
            ]),
        );

        $response->assertNotFound();
    }
    public function test_client_sees_public_stage_details_without_private_information(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $plan = $this->createPlan($psychologist, $client, $record);
        $stages = $this->createStages($plan);

        $plan->forceFill([
            'activated_at' => now(),
            'current_stage' => 2,
            'main_problem' => 'PRIVATE_MAIN_PROBLEM_MARKER',
            'status_reason' => 'PRIVATE_STATUS_REASON_MARKER',
        ])->save();

        $record->update([
            'clinical_formulation' => 'PRIVATE_FORMULATION_MARKER',
        ]);

        $this->actingAs($psychologist)->post(
            route('psychologist.clinical-notes.store', $record),
            ['private_note' => 'PRIVATE_CLINICAL_NOTE_MARKER'],
        )->assertSessionHasNoErrors();

        $appointment = $this->createSessionAppointment($psychologist, $client);

        $appointment->forceFill([
            'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
            'attendance_status' => Appointment::ATTENDANCE_HELD,
            'treatment_plan_id' => $plan->id,
            'treatment_plan_stage_id' => $stages[1]->id,
        ])->save();

        $response = $this->actingAs($client)
            ->get(route('client.dashboard'));

        $response
            ->assertOk()
            ->assertSeeText('هدف مرحله 1')
            ->assertSeeText('هدف مرحله 2')
            ->assertSeeText('هدف مرحله 3')
            ->assertSeeText('مرحله فعلی')
            ->assertDontSee('PRIVATE_MAIN_PROBLEM_MARKER')
            ->assertDontSee('PRIVATE_STATUS_REASON_MARKER')
            ->assertDontSee('PRIVATE_FORMULATION_MARKER')
            ->assertDontSee('PRIVATE_CLINICAL_NOTE_MARKER');

        $visiblePlan = $response->viewData('treatmentPlans')->sole();

        $this->assertSame(2, $visiblePlan->current_stage);
        $this->assertSame(1, $visiblePlan->held_sessions_count);
        $this->assertSame(8, $visiblePlan->progress_percent);
        $this->assertSame(
            1,
            $visiblePlan->stages
                ->firstWhere('stage_number', 2)
                ->held_sessions_count,
        );

        $this->assertArrayNotHasKey(
            'main_problem',
            $visiblePlan->getAttributes(),
        );
        $this->assertArrayNotHasKey(
            'status_reason',
            $visiblePlan->getAttributes(),
        );
    }

    public function test_stage_details_require_explicit_activation(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $plan = $this->createPlan($psychologist, $client, $record);
        $stages = $this->createStages($plan);

        $stages[0]->update(['goal' => 'ACTIVATION_REQUIRED_GOAL']);

        // حتی جلسه تأییدشده و برگزارشده، مسیر را فعال نمی‌کند.
        $appointment = $this->createSessionAppointment($psychologist, $client);

        $appointment->forceFill([
            'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
            'attendance_status' => Appointment::ATTENDANCE_HELD,
            'treatment_plan_id' => $plan->id,
            'treatment_plan_stage_id' => $stages[0]->id,
        ])->save();

        $this->actingAs($client)
            ->get(route('client.dashboard'))
            ->assertOk()
            ->assertDontSee('ACTIVATION_REQUIRED_GOAL')
            ->assertViewHas(
                'treatmentPlans',
                fn ($plans) => $plans->isEmpty(),
            );

        $this->actingAs($psychologist)
            ->post(route('psychologist.treatment-plans.activate', $plan))
            ->assertRedirect(
                route('psychologist.treatment-plans.edit', $plan),
            )
            ->assertSessionHasNoErrors();

        $this->actingAs($client)
            ->get(route('client.dashboard'))
            ->assertOk()
            ->assertSeeText('ACTIVATION_REQUIRED_GOAL');
    }

    public function test_client_cannot_see_another_clients_stage_details(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $plan = $this->createPlan($psychologist, $client, $record);
        $stages = $this->createStages($plan);

        $plan->forceFill(['activated_at' => now()])->save();
        $stages[0]->update(['goal' => 'OTHER_CLIENT_GOAL_MARKER']);

        $otherClient = User::factory()->client()->create();

        $this->actingAs($otherClient)
            ->get(route('client.dashboard'))
            ->assertOk()
            ->assertDontSee('OTHER_CLIENT_GOAL_MARKER')
            ->assertViewHas(
                'treatmentPlans',
                fn ($plans) => $plans->isEmpty(),
            );
    }

    public function test_dashboard_hides_plan_with_mismatched_record(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $plan = $this->createPlan($psychologist, $client, $record);
        $stages = $this->createStages($plan);

        $otherClient = User::factory()->client()->create();
        $otherRecord = $this->createClinicalRecord($otherClient);

        $plan->forceFill([
            'activated_at' => now(),
            'clinical_record_id' => $otherRecord->id,
        ])->save();

        $stages[0]->update(['goal' => 'MISMATCHED_RECORD_GOAL']);

        $this->actingAs($client)
            ->get(route('client.dashboard'))
            ->assertOk()
            ->assertDontSee('MISMATCHED_RECORD_GOAL')
            ->assertViewHas(
                'treatmentPlans',
                fn ($plans) => $plans->isEmpty(),
            );
    }

    public function test_stage_goal_is_escaped_and_missing_goal_has_fallback(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();

        $plan = $this->createPlan($psychologist, $client, $record);
        $stages = $this->createStages($plan);

        $plan->forceFill(['activated_at' => now()])->save();

        $unsafeGoal = '<script>alert("stage-goal")</script>';

        $stages[0]->update(['goal' => $unsafeGoal]);
        $stages[1]->update([
            'goal' => null,
            'estimated_sessions' => null,
        ]);

        $this->actingAs($client)
            ->get(route('client.dashboard'))
            ->assertOk()
            ->assertSee(e($unsafeGoal), false)
            ->assertDontSee($unsafeGoal, false)
            ->assertSeeText('هدف این مرحله هنوز ثبت نشده است.')
            ->assertSeeText('بدون تخمین');
    }

    public function test_psychologist_cannot_edit_a_plan_with_mismatched_record_client(): void
    {
        $psychologist = User::factory()->psychologist()->create();
        $client = User::factory()->client()->create();
        $otherClient = User::factory()->client()->create();

        $this->createCompletedAppointment($psychologist, $client);
        $record = $this->createClinicalRecord($otherClient);

        $plan = TreatmentPlan::withoutEvents(function () use (
            $psychologist,
            $client,
            $record,
        ): TreatmentPlan {
            return TreatmentPlan::query()->forceCreate([
                'psychologist_id' => $psychologist->id,
                'client_id' => $client->id,
                'clinical_record_id' => $record->id,
                'title' => 'نقشه نامعتبر',
                'status' => TreatmentPlan::STATUS_ACTIVE,
                'active_plan_guard' => $client->id,
                'current_stage' => TreatmentPlan::STAGE_ROOT_CAUSE,
            ]);
        });

        $response = $this->actingAs($psychologist)->get(
            route('psychologist.treatment-plans.edit', [
                'treatmentPlan' => $plan,
            ]),
        );

        $response->assertNotFound();
    }


    public function test_free_session_clears_plan_and_stage_ids(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $stage = $this->createStages($plan)[0];

        $appointment = $this->createSessionAppointment(
            $psychologist,
            $client,
        );

        $appointment->forceFill([
            'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
            'treatment_plan_id' => $plan->id,
            'treatment_plan_stage_id' => $stage->id,
        ])->save();

        $response = $this->actingAs($psychologist)->put(
            route('psychologist.appointments.session.update', $appointment),
            [
                'therapy_session_type' => Appointment::THERAPY_TYPE_FREE,
                'attendance_status' => Appointment::ATTENDANCE_PENDING,
                'treatment_plan_id' => $plan->id,
                'treatment_plan_stage_id' => $stage->id,
            ],
        );

        $response
            ->assertSessionHasNoErrors()
            ->assertRedirect(
                route('psychologist.appointments.session.show', $appointment),
            )
            ->assertSessionHas('status');

        $appointment->refresh();

        $this->assertNull($appointment->treatment_plan_id);
        $this->assertNull($appointment->treatment_plan_stage_id);
        $this->assertSame(
            Appointment::THERAPY_TYPE_FREE,
            $appointment->therapy_session_type,
        );

        $this->assertDatabaseCount('clinical_notes', 0);
    }

    public function test_plan_session_requires_a_plan_and_stage(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $appointment = $this->createSessionAppointment(
            $psychologist,
            $client,
        );

        $url = route(
            'psychologist.appointments.session.update',
            $appointment,
        );

        $withoutPlan = $this->actingAs($psychologist)->put($url, [
            'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
            'attendance_status' => Appointment::ATTENDANCE_PENDING,
        ]);

        $withoutPlan->assertSessionHasErrors([
            'treatment_plan_id',
            'treatment_plan_stage_id',
        ]);

        $plan = $this->createPlan($psychologist, $client, $record);

        $withoutStage = $this->actingAs($psychologist)->put($url, [
            'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
            'attendance_status' => Appointment::ATTENDANCE_PENDING,
            'treatment_plan_id' => $plan->id,
        ]);

        $withoutStage->assertSessionHasErrors('treatment_plan_stage_id');

        $this->assertSessionRemainsUnassigned($appointment);
    }

    public function test_plan_session_rejects_stage_belonging_to_another_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $firstPlan = $this->createPlan($psychologist, $client, $record);
        $secondPlan = $this->createPlanForAnotherClient();
        $foreignStage = $this->createStages($secondPlan)[0];

        $appointment = $this->createSessionAppointment(
            $psychologist,
            $client,
        );

        $response = $this->actingAs($psychologist)->put(
            route('psychologist.appointments.session.update', $appointment),
            [
                'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
                'attendance_status' => Appointment::ATTENDANCE_PENDING,
                'treatment_plan_id' => $firstPlan->id,
                'treatment_plan_stage_id' => $foreignStage->id,
            ],
        );

        $response->assertSessionHasErrors('treatment_plan_stage_id');

        $this->assertSessionRemainsUnassigned($appointment);
    }

    public function test_plan_session_cannot_be_added_to_an_archived_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $stage = $this->createStages($plan)[0];

        $plan->update([
            'status' => TreatmentPlan::STATUS_COMPLETED,
            'status_reason' => 'تکمیل‌شده',
            'active_plan_guard' => null,
        ]);

        $appointment = $this->createSessionAppointment(
            $psychologist,
            $client,
        );

        $response = $this->actingAs($psychologist)->put(
            route('psychologist.appointments.session.update', $appointment),
            [
                'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
                'attendance_status' => Appointment::ATTENDANCE_PENDING,
                'treatment_plan_id' => $plan->id,
                'treatment_plan_stage_id' => $stage->id,
            ],
        );

        $response->assertSessionHasErrors('treatment_plan_id');

        $this->assertSessionRemainsUnassigned($appointment);
    }

    public function test_unrelated_psychologist_cannot_create_note_for_the_record(): void
    {
        [$owner, $client, $record] = $this->clinicalContext();
        $otherPsychologist = User::factory()->psychologist()->create();

        $response = $this->actingAs($otherPsychologist)->post(
            route('psychologist.clinical-notes.store', [
                'clinicalRecord' => $record,
            ]),
            [
                'private_note' => 'دسترسی غیرمجاز',
            ],

        );

        $response->assertNotFound();
        $this->assertDatabaseCount('clinical_notes', 0);
    }

    public function test_active_plan_can_be_deleted_without_deleting_its_session(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $stage = $this->createStages($plan)[0];

        // فعال‌سازی برای مراجع هم مانع حذف نیست.
        $plan->forceFill(['activated_at' => now()])->save();

        $appointment = $this->createSessionAppointment($psychologist, $client);
        $appointment->forceFill([
            'therapy_session_type' => Appointment::THERAPY_TYPE_PLAN,
            'treatment_plan_id' => $plan->id,
            'treatment_plan_stage_id' => $stage->id,
            'attendance_status' => Appointment::ATTENDANCE_HELD,
            'session_subject' => 'موضوع جلسه',
            'session_discussion' => 'شرح جلسه',
            'session_recommendations' => 'توصیه جلسه',
            'session_exercises' => 'تمرین جلسه',
            'client_note' => 'یادداشت مراجع',
        ])->save();

        $before = $appointment->getRawOriginal();

        $this->actingAs($psychologist)
            ->delete(route('psychologist.treatment-plans.destroy', $plan))
            ->assertSessionHasNoErrors()
            ->assertRedirect(route('psychologist.clinical-records.show', $client))
            ->assertSessionHas('status');

        $this->assertDatabaseMissing('treatment_plans', ['id' => $plan->id]);
        $this->assertDatabaseMissing('treatment_plan_stages', [
            'treatment_plan_id' => $plan->id,
        ]);

        $appointment->refresh();

        $this->assertNull($appointment->treatment_plan_id);
        $this->assertNull($appointment->treatment_plan_stage_id);
        $this->assertSame(
            Appointment::THERAPY_TYPE_FREE,
            $appointment->therapy_session_type,
        );

        // تمام فیلدهای دیگر نوبت باید دست‌نخورده باشند.
        foreach ($before as $field => $value) {
            if (in_array($field, [
                'treatment_plan_id',
                'treatment_plan_stage_id',
                'therapy_session_type',
                'updated_at',
            ], true)) {
                continue;
            }

            $this->assertSame(
                $value,
                $appointment->getRawOriginal($field),
                "Appointment field changed: {$field}",
            );
        }

        $this->assertDatabaseHas('clinical_records', ['id' => $record->id]);
        $this->assertDatabaseCount('treatment_plans', 0);

        // ساخت مسیر جدید اختیاری است، اما دیگر توسط guard مسدود نمی‌شود.
        $this->actingAs($psychologist)->post(
            route('psychologist.treatment-plans.store', $record),
            ['title' => 'مسیر جدید'],
        )->assertSessionHasNoErrors();

        $this->assertDatabaseCount('treatment_plans', 1);
        $newPlan = TreatmentPlan::query()->sole();
        $this->assertSame('مسیر جدید', $newPlan->title);
        $this->assertNull($newPlan->activated_at);

        // جلسه قدیمی خودکار به مسیر جدید متصل نمی‌شود.
        $this->assertNull($appointment->fresh()->treatment_plan_id);
    }
    public function test_deleting_plan_preserves_legacy_private_note(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $stage = $this->createStages($plan)[0];

        $this->actingAs($psychologist)->post(
            route('psychologist.clinical-notes.store', $record),
            ['private_note' => 'یادداشت محرمانه محفوظ'],
        )->assertSessionHasNoErrors();

        $note = ClinicalNote::query()->sole();
        $note->forceFill([
            'treatment_plan_id' => $plan->id,
            'treatment_plan_stage_id' => $stage->id,
            'session_type' => ClinicalNote::SESSION_TYPE_PLAN,
        ])->save();

        $before = $note->getRawOriginal();

        $this->actingAs($psychologist)
            ->delete(route('psychologist.treatment-plans.destroy', $plan))
            ->assertSessionHasNoErrors();

        $note->refresh();

        $this->assertNull($note->treatment_plan_id);
        $this->assertNull($note->treatment_plan_stage_id);
        $this->assertSame(ClinicalNote::SESSION_TYPE_FREE, $note->session_type);

        foreach ($before as $field => $value) {
            if (in_array($field, [
                'treatment_plan_id',
                'treatment_plan_stage_id',
                'session_type',
                'updated_at',
            ], true)) {
                continue;
            }

            $this->assertSame($value, $note->getRawOriginal($field));
        }
    }
    public function test_all_archived_plan_statuses_are_protected_from_deletion(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $this->createStages($plan);

        foreach ([
                     TreatmentPlan::STATUS_COMPLETED,
                     TreatmentPlan::STATUS_DROPPED_OUT,
                     TreatmentPlan::STATUS_REFERRED,
                 ] as $status) {
            $plan->update([
                'status' => $status,
                'active_plan_guard' => null,
                'status_reason' => 'علت آرشیو',
            ]);

            $this->actingAs($psychologist)
                ->delete(route('psychologist.treatment-plans.destroy', $plan))
                ->assertSessionHasErrors('treatment_plan');

            $this->assertDatabaseHas('treatment_plans', [
                'id' => $plan->id,
                'status' => $status,
                'status_reason' => 'علت آرشیو',
            ]);

            $this->assertSame(3, $plan->stages()->count());
        }
    }
    public function test_another_psychologist_cannot_delete_the_plan(): void
    {
        [$owner, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($owner, $client, $record);
        $this->createStages($plan);

        $other = User::factory()->psychologist()->create();

        $this->actingAs($other)
            ->delete(route('psychologist.treatment-plans.destroy', $plan))
            ->assertNotFound();

        $this->assertDatabaseHas('treatment_plans', ['id' => $plan->id]);
        $this->assertSame(3, $plan->stages()->count());
    }

    public function test_guest_cannot_delete_a_treatment_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);

        $this->delete(route('psychologist.treatment-plans.destroy', $plan))
            ->assertRedirect(route('auth.login'));

        $this->assertDatabaseHas('treatment_plans', ['id' => $plan->id]);
    }

    public function test_client_cannot_delete_a_treatment_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);

        $response = $this->actingAs($client)
            ->delete(route('psychologist.treatment-plans.destroy', $plan));

        // بسته به قرارداد Role middleware، دسترسی با 403 یا 404 رد می‌شود.
        $this->assertContains($response->getStatusCode(), [403, 404]);
        $this->assertDatabaseHas('treatment_plans', ['id' => $plan->id]);
    }

    public function test_plan_with_mismatched_record_client_cannot_be_deleted(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);

        $otherClient = User::factory()->client()->create();
        $otherRecord = $this->createClinicalRecord($otherClient);

        $plan->update(['clinical_record_id' => $otherRecord->id]);

        $this->actingAs($psychologist)
            ->delete(route('psychologist.treatment-plans.destroy', $plan))
            ->assertNotFound();

        $this->assertDatabaseHas('treatment_plans', ['id' => $plan->id]);
    }
    public function test_delete_button_is_only_shown_for_active_plan(): void
    {
        [$psychologist, $client, $record] = $this->clinicalContext();
        $plan = $this->createPlan($psychologist, $client, $record);
        $this->createStages($plan);

        $url = route('psychologist.treatment-plans.edit', $plan);

        $this->actingAs($psychologist)->get($url)
            ->assertOk()
            ->assertSee('حذف دائمی مسیر');

        $plan->update([
            'status' => TreatmentPlan::STATUS_COMPLETED,
            'active_plan_guard' => null,
            'status_reason' => 'تکمیل درمان',
        ]);

        $this->actingAs($psychologist)->get($url)
            ->assertOk()
            ->assertDontSee('حذف دائمی مسیر');
    }

    private function createSessionAppointment(
        User $psychologist,
        User $client,
    ): Appointment {
        $appointment = Appointment::query()
            ->where('psychologist_id', $psychologist->id)
            ->where('client_id', $client->id)
            ->sole();

        $appointment->forceFill([
            'status' => Appointment::STATUS_CONFIRMED,
            'therapy_session_type' => Appointment::THERAPY_TYPE_FREE,
            'attendance_status' => Appointment::ATTENDANCE_PENDING,
            'treatment_plan_id' => null,
            'treatment_plan_stage_id' => null,
        ])->save();

        return $appointment->refresh();
    }

    private function assertSessionRemainsUnassigned(
        Appointment $appointment,
    ): void {
        $appointment->refresh();

        $this->assertSame(
            Appointment::THERAPY_TYPE_FREE,
            $appointment->therapy_session_type,
        );
        $this->assertSame(
            Appointment::ATTENDANCE_PENDING,
            $appointment->attendance_status,
        );
        $this->assertNull($appointment->treatment_plan_id);
        $this->assertNull($appointment->treatment_plan_stage_id);
    }

    private function clinicalContext(): array
    {
        $psychologist = User::factory()->psychologist()->create();
        $client = User::factory()->client()->create();

        $this->createCompletedAppointment($psychologist, $client);
        $record = $this->createClinicalRecord($client);

        return [$psychologist, $client, $record];
    }

    private function createClinicalRecord(User $client): ClinicalRecord
    {
        return ClinicalRecord::query()->create([
            'client_id' => $client->id,
        ]);
    }

    private function createCompletedAppointment(
        User $psychologist,
        User $client,
    ): Appointment {
        return Appointment::factory()
            ->forPsychologist($psychologist)
            ->forClient($client)
            ->completed()
            ->create();
    }

    private function createPlan(
        User $psychologist,
        User $client,
        ClinicalRecord $record,
    ): TreatmentPlan {
        return TreatmentPlan::query()->create([
            'psychologist_id' => $psychologist->id,
            'client_id' => $client->id,
            'clinical_record_id' => $record->id,
            'title' => 'نقشه درمان',
            'main_problem' => 'مسئله اصلی',
            'status' => TreatmentPlan::STATUS_ACTIVE,
            'active_plan_guard' => $client->id,
            'current_stage' => TreatmentPlan::STAGE_ROOT_CAUSE,
        ]);
    }

    private function createPlanForAnotherClient(): TreatmentPlan
    {
        $psychologist = User::factory()->psychologist()->create();
        $client = User::factory()->client()->create();

        $this->createCompletedAppointment($psychologist, $client);
        $record = $this->createClinicalRecord($client);

        return $this->createPlan($psychologist, $client, $record);
    }

    private function createStages(TreatmentPlan $plan): array
    {
        return collect([1, 2, 3])->map(
            static fn (int $stageNumber): TreatmentPlanStage =>
            TreatmentPlanStage::query()->create([
                'treatment_plan_id' => $plan->id,
                'stage_number' => $stageNumber,
                'title' => "مرحله {$stageNumber}",
                'goal' => "هدف مرحله {$stageNumber}",
                'estimated_sessions' => 4,
            ]),
        )->all();
    }

    private function planUpdatePayload(): array
    {
        return [
            'title' => 'عنوان به‌روزشده',
            'main_problem' => 'مسئله به‌روزشده',
            'current_stage' => TreatmentPlan::STAGE_STABILIZATION,
            'stages' => [
                1 => [
                    'goal' => 'هدف به‌روزشده مرحله 1',
                    'estimated_sessions' => 4,
                ],
                2 => [
                    'goal' => 'هدف به‌روزشده مرحله 2',
                    'estimated_sessions' => 5,
                ],
                3 => [
                    'goal' => 'هدف به‌روزشده مرحله 3',
                    'estimated_sessions' => 6,
                ],
            ],
        ];
    }
}
