<?php
    $isOtp = ($step ?? 'mobile') === 'otp';
    $codeLength = (int) config('services.otp.length', 6);
?>
    <!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($isOtp ? 'تأیید شماره موبایل' : 'ورود به حساب کاربری'); ?> | کریم محمدزاده</title>
    <link rel="stylesheet" href="<?php echo e(asset('website/style/care-auth.css')); ?>">
</head>
<body class="care-auth">
<main class="auth-shell">
    <header class="auth-brand">
        <a href="<?php echo e(url('/')); ?>">کریم محمدزاده</a>
        <p>روان‌شناس بالینی</p>
    </header>
    <section class="auth-card" aria-labelledby="auth-title">
        <p class="auth-step">ورود با شماره موبایل · مرحله <?php echo e($isOtp ? '۲ از ۲' : '۱ از ۲'); ?></p>
        <h1 id="auth-title"><?php echo e($isOtp ? 'کد تأیید را وارد کنید' : 'به حساب خود وارد شوید'); ?></h1>
        <?php if($isOtp): ?>
            <p class="auth-description">کد ارسال‌شده به شماره <bdi dir="ltr"><?php echo e($mobile); ?></bdi> را وارد کنید.</p>
            <a class="auth-edit" href="<?php echo e(route('auth.login')); ?>">اصلاح شماره موبایل</a>
        <?php else: ?>
            <p class="auth-description">برای ورود یا ایجاد حساب، شماره موبایل خود را وارد کنید.</p>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <p class="auth-notice" role="status"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="auth-errors" role="alert">
                <p>لطفاً موارد زیر را بررسی کنید:</p>
                <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($message); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
        <?php endif; ?>

        <?php if(! $isOtp): ?>
            <form method="POST" action="<?php echo e(route('auth.send-otp')); ?>">
                <?php echo csrf_field(); ?>
                <label class="auth-label" for="mobile">شماره موبایل</label>
                <input class="auth-input" id="mobile" type="tel" name="mobile" value="<?php echo e(old('mobile')); ?>" autocomplete="tel" inputmode="tel" dir="ltr" required aria-describedby="mobile-hint<?php echo e($errors->has('mobile') ? ' mobile-error' : ''); ?>" <?php if($errors->has('mobile')): ?> aria-invalid="true" <?php endif; ?>>
                <p id="mobile-hint" class="auth-hint">مثلاً 09123456789؛ کد ورود با پیامک ارسال می‌شود.</p>
                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p id="mobile-error" class="auth-field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label class="auth-remember" for="remember">
                    <input id="remember" type="checkbox" name="remember" value="1" <?php if(old('remember', false)): echo 'checked'; endif; ?> aria-describedby="remember-hint">
                    <span>مرا به خاطر بسپار — ۳۰ روز</span>
                </label>
                <p id="remember-hint" class="auth-hint">در دستگاه‌های عمومی یا مشترک این گزینه را فعال نکنید.</p>
                <button class="auth-button" type="submit">دریافت کد ورود <span aria-hidden="true">←</span></button>
            </form>
        <?php else: ?>
            <form method="POST" action="<?php echo e(route('auth.verify-otp')); ?>">
                <?php echo csrf_field(); ?>
                <label class="auth-label" for="code">کد تأیید <?php echo e($codeLength); ?> رقمی</label>
                <input class="auth-input auth-code" id="code" type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="<?php echo e($codeLength); ?>" dir="ltr" required aria-describedby="code-hint<?php echo e($errors->has('code') ? ' code-error' : ''); ?>" <?php if($errors->has('code')): ?> aria-invalid="true" <?php endif; ?>>
                <p id="code-hint" class="auth-hint">اعتبار هر کد: <?php echo e((int) config('services.otp.expires_in', 2)); ?> دقیقه از زمان صدور.</p>
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p id="code-error" class="auth-field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="auth-button" type="submit">تأیید و ورود <span aria-hidden="true">←</span></button>
            </form>
            <div class="auth-resend">
                <p class="auth-hint">کد را دریافت نکردید؟ ارسال مجدد پس از <?php echo e((int) config('services.otp.resend_seconds', 60)); ?> ثانیه از ارسال قبلی امکان‌پذیر است.</p>
                <form method="POST" action="<?php echo e(route('auth.resend-otp')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="auth-button auth-secondary" type="submit">ارسال مجدد کد</button>
                </form>
            </div>
        <?php endif; ?>
    </section>
    <footer class="auth-footer">
        <p>کد ورود خود را در اختیار دیگران قرار ندهید.</p>
        <a href="<?php echo e(url('/')); ?>">بازگشت به سایت</a>
    </footer>
</main>
</body>
</html>
<?php /**PATH C:\wamp64\www\psychology-app\resources\views/auth.blade.php ENDPATH**/ ?>