<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'کریم محمدزاده'); ?></title>
    <?php if (! empty(trim($__env->yieldContent('description')))): ?>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <?php endif; ?>
    <meta name="robots" content="<?php echo $__env->yieldContent('robots', 'index, follow'); ?>">
    <meta name="author" content="کریم محمدزاده">
    <meta name="theme-color" content="#075B3F">
    <link rel="canonical" href="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">

    <meta property="og:locale" content="fa_IR">
    <meta property="og:type" content="<?php echo $__env->yieldContent('og_type', 'website'); ?>">
    <meta property="og:site_name" content="کریم محمدزاده">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'کریم محمدزاده'); ?>">
    <?php if (! empty(trim($__env->yieldContent('description')))): ?>
        <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>">
        <meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>">
    <?php endif; ?>
    <meta property="og:url" content="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('social_image', asset('website/images/logo-mini.webp')); ?>">
    <meta property="og:image:alt" content="<?php echo $__env->yieldContent('social_image_alt', 'کریم محمدزاده'); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('title', 'کریم محمدزاده'); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('social_image', asset('website/images/logo-mini.webp')); ?>">
    <meta name="twitter:image:alt" content="<?php echo $__env->yieldContent('social_image_alt', 'کریم محمدزاده'); ?>">

    <link rel="icon" href="<?php echo e(asset('website/images/favicon.ico')); ?>">

    
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="<?php echo e(asset('website/js/tw.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset('website/style/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('website/style/style.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('website/style/care-public-shell.css')); ?>">

    <style>
        html, body {
            font-family: 'IRANYekan', 'IRANSansX', system-ui, sans-serif;
        }
        [x-cloak] { display: none !important; }
        body.menu-open { overflow: hidden; }
    </style>

    <?php echo $__env->yieldPushContent('head'); ?>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.9/dist/cdn.min.js"></script>
</head>
<body class="<?php echo $__env->yieldContent('body_class'); ?>">

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('website.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
<script defer src="<?php echo e(asset('website/js/care-public-shell.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\wamp64\www\psychology-app\resources\views/website/layouts/app.blade.php ENDPATH**/ ?>