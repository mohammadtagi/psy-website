<div class="panel-mobile-account-actions" aria-label="دسترسی‌های حساب">
    <a href="<?php echo e(route('home')); ?>">بازگشت به وب‌سایت</a>
    <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">خروج از حساب</button></form>
</div>
<?php /**PATH C:\wamp64\www\psychology-app\resources\views/components/layouts/panel-account-actions.blade.php ENDPATH**/ ?>