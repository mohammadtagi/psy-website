<?php
    $role = auth()->user()?->role;
    $navigation = match ($role) {
        'psychologist' => [
            ['route'=>'psychologist.dashboard', 'label'=>'داشبورد', 'icon'=>'home', 'patterns'=>['psychologist.dashboard']],
            ['route'=>'psychologist.appointments.index', 'label'=>'نوبت‌ها', 'icon'=>'calendar', 'patterns'=>['psychologist.appointments.*']],
            ['route'=>'psychologist.clients.index', 'label'=>'مراجعان', 'icon'=>'users', 'patterns'=>['psychologist.clients.*','psychologist.clinical-records.*','psychologist.clinical-notes.*','psychologist.clinical-attachments.*','psychologist.treatment-plans.*']],
            ['route'=>'psychologist.availabilities.index', 'label'=>'زمان‌های حضور', 'icon'=>'clock', 'patterns'=>['psychologist.availabilities.*']],
            ['route'=>'psychologist.discounts.index', 'label'=>'کدهای تخفیف', 'icon'=>'ticket', 'patterns'=>['psychologist.discounts.*']],
        ],
        'client' => [
            ['route'=>'client.dashboard', 'label'=>'داشبورد', 'icon'=>'home', 'patterns'=>['client.dashboard']],
            ['route'=>'client.appointments.index', 'label'=>'نوبت‌های من', 'icon'=>'calendar', 'patterns'=>['client.appointments.*']],
            ['route'=>'booking.index', 'label'=>'رزرو جلسه', 'icon'=>'clock', 'patterns'=>['booking.*']],
            ['route'=>'client.profile.show', 'label'=>'پروفایل', 'icon'=>'users', 'patterns'=>['client.profile.*']],
        ],
        'admin' => [
            ['route'=>'admin.dashboard', 'label'=>'داشبورد مدیر', 'icon'=>'home', 'patterns'=>['admin.*']],
        ],
        default => [
            ['route'=>'home', 'label'=>'وب‌سایت', 'icon'=>'home', 'patterns'=>['home']],
            ['route'=>'booking.index', 'label'=>'رزرو جلسه', 'icon'=>'calendar', 'patterns'=>['booking.*']],
            ['route'=>'auth.login', 'label'=>'ورود', 'icon'=>'users', 'patterns'=>['auth.*']],
        ],
    };
    $modernPanel = in_array($role, ['client', 'psychologist'], true);
    $roleLabel = match ($role) { 'psychologist'=>'پنل مشاور', 'client'=>'پنل مراجع', 'admin'=>'پنل مدیر', default=>'سامانه مشاوره' };
    $pageTitle = isset($title) && is_string($title) ? $title : $roleLabel;
?>
    <!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', $pageTitle); ?> | کریم محمدزاده</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('website/style/care-shell.css')); ?>">
    <?php if($modernPanel): ?><link rel="stylesheet" href="<?php echo e(asset('website/style/care-panel-navigation.css')); ?>?v=1"><?php endif; ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="care-shell <?php echo e($modernPanel ? 'care-panel-modern' : ''); ?>">
<a class="care-skip" href="#care-content">رفتن به محتوای اصلی</a>
<?php echo $__env->make('components.layouts.care-icons', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if($modernPanel): ?><?php echo $__env->make('components.layouts.panel-navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endif; ?>
<aside class="care-sidebar" aria-label="منوی اصلی">
    <a class="care-brand" href="<?php echo e(route($navigation[0]['route'])); ?>"><span class="care-brand-mark"><img src="<?php echo e(asset('website/images/logo-mini.png')); ?>"></span><span>کریم محمدزاده<small>سامانه مدیریت مشاوره</small></span></a>
    <p class="care-caption"><?php echo e($roleLabel); ?></p>
    <nav aria-label="بخش‌های سامانه">
        <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="care-nav-item" href="<?php echo e(route($item['route'])); ?>" <?php if(request()->routeIs(...$item['patterns'])): ?> aria-current="page" <?php endif; ?>><svg class="icon" aria-hidden="true"><use href="#<?php echo e($item['icon']); ?>"/></svg><?php echo e($item['label']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
    <div class="care-sidebar-bottom"><p>فضایی برای تمرکز بر مراقبت</p><a href="<?php echo e(route('home')); ?>">بازگشت به وب‌سایت</a><?php if(auth()->guard()->check()): ?><form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="care-logout">خروج از حساب</button></form><?php endif; ?></div>
</aside>
<div class="care-workspace">
    <header class="care-topbar">
        <div><small><?php echo e($roleLabel); ?></small><strong><?php echo $__env->yieldContent('title', $pageTitle); ?></strong></div>
        <div class="care-date"><?php echo e(\App\Support\PersianDate::format(now('Asia/Tehran'), 'EEEE، d MMMM yyyy')); ?><small>ساعت‌ها به وقت تهران</small></div>
        <details class="care-mobile-menu"><summary><svg class="icon" aria-hidden="true"><use href="#menu"/></svg>منو</summary><nav aria-label="منوی موبایل">
                <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route($item['route'])); ?>" <?php if(request()->routeIs(...$item['patterns'])): ?> aria-current="page" <?php endif; ?>><?php echo e($item['label']); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('home')); ?>">وب‌سایت</a>
                <?php if(auth()->guard()->check()): ?><form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="care-logout" type="submit">خروج از حساب</button></form><?php endif; ?>
            </nav></details>
    </header>
    <div id="care-content" class="care-content" tabindex="-1">
        <?php if(isset($slot) && !is_array($slot)): ?><?php echo e($slot); ?><?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php if($modernPanel): ?><?php echo $__env->make('components.layouts.panel-account-actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endif; ?>
    <footer class="care-footer">سامانه اختصاصی مدیریت خدمات مشاوره · کریم محمدزاده</footer>
</div>
<nav class="care-bottom-nav" style="--care-nav-count: <?php echo e($modernPanel ? count($navigation) : min(count($navigation), 4)); ?>" aria-label="دسترسی سریع موبایل">
    <?php $__currentLoopData = ($modernPanel ? $navigation : array_slice($navigation, 0, 4)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route($item['route'])); ?>" <?php if(request()->routeIs(...$item['patterns'])): ?> aria-current="page" <?php endif; ?>><svg class="icon" aria-hidden="true"><use href="#<?php echo e($item['icon']); ?>"/></svg><span><?php echo e($item['label']); ?></span></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\psychology-app\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>