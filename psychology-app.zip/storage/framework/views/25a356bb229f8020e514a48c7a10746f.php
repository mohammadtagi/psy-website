<header class="panel-navigation-header">
    <nav class="panel-navigation-links" aria-label="بخش‌های سامانه">
        <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>" <?php if(request()->routeIs(...($item['patterns'] ?? [$item['route']]))): ?> aria-current="page" <?php endif; ?>>
                <svg class="icon" aria-hidden="true"><use href="#<?php echo e($item['icon']); ?>"/></svg>
                <span><?php echo e($item['label']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
    <div class="panel-header-actions">
        <a href="<?php echo e(route('home')); ?>">وب‌سایت</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">خروج از حساب</button></form>
    </div>
</header>
<?php /**PATH C:\wamp64\www\psychology-app\resources\views/components/layouts/panel-navigation.blade.php ENDPATH**/ ?>