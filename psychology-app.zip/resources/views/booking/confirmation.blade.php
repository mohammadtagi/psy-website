@php use Carbon\CarbonImmutable; @endphp
@php use App\Support\PersianDate; @endphp
@php use App\Models\Appointment; @endphp
@extends('components.layouts.app')

@section('title', 'جزئیات نوبت')

@push('styles')
    <link rel="stylesheet" href="{{ asset('website/style/care-booking-review.css') }}?v=1">
    <link rel="stylesheet" href="{{ asset('website/style/care-booking-followup.css') }}?v=1">
@endpush

@section('content')
    @php
        $timezone = 'Asia/Tehran';

        $startsAt = CarbonImmutable::instance(
            $appointment->starts_at
        )->setTimezone($timezone);

        $endsAt = CarbonImmutable::instance(
            $appointment->ends_at
        )->setTimezone($timezone);

        $sessionType = match ($appointment->session_type) {
            Appointment::SESSION_TYPE_ONLINE => 'آنلاین',
            Appointment::SESSION_TYPE_IN_PERSON => 'حضوری',
            default => 'نامشخص',
        };

        $now = CarbonImmutable::now('UTC');

        $isPendingPayment = $appointment->status
            === Appointment::STATUS_PENDING_PAYMENT;

        $holdExpiresAt = $appointment->hold_expires_at
            ? CarbonImmutable::instance(
                $appointment->hold_expires_at
            )->setTimezone($timezone)
            : null;

        $hasActiveHold = $isPendingPayment
            && $holdExpiresAt !== null
            && $holdExpiresAt->gt($now);

        $hasExpiredHold = $isPendingPayment && ! $hasActiveHold;

        $hasSessionStarted = $startsAt->lte($now);


        $statusLabel = match ($appointment->status) {
            Appointment::STATUS_CONFIRMED => 'تأیید شده',
Appointment::STATUS_PENDING_PAYMENT =>
    $hasExpiredHold
        ? 'مهلت رزرو موقت پایان یافته'
        : 'در انتظار پرداخت',

            Appointment::STATUS_CANCELLED => 'لغو شده',
            Appointment::STATUS_COMPLETED => 'تکمیل شده',
            Appointment::STATUS_NO_SHOW => 'عدم حضور',
            default => $appointment->status,
        };

        $isConfirmed = $appointment->status
            === Appointment::STATUS_CONFIRMED;

        $statusClasses = match ($appointment->status) {
            Appointment::STATUS_CONFIRMED =>
                'bg-green-100 text-green-800',

            Appointment::STATUS_PENDING_PAYMENT =>
                'bg-amber-100 text-amber-800',

            Appointment::STATUS_CANCELLED =>
                'bg-red-100 text-red-800',

            default => 'bg-gray-100 text-gray-800',
        };

        if ($hasExpiredHold) {
    $statusClasses = 'bg-gray-100 text-gray-800';
}

    @endphp

    <main class="cbc mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8" dir="rtl">
        <nav aria-label="مراحل رزرو" class="cbc-steps">
            <span>۱ · اطلاعات حساب</span>
            <span>۲ · تاریخ و ساعت</span>
            <span aria-current="step">۳ · بررسی و پرداخت</span>
        </nav>
        <section class="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
            <div
                class="border-b px-6 py-8 text-center {{ $isConfirmed
                    ? 'border-green-200 bg-green-50'
                    : 'border-gray-200 bg-gray-50' }}"
            >
                <h1 class="text-2xl font-bold text-gray-900">
                    {{ $isConfirmed ? 'نوبت شما تأیید شده است' : ($isPendingPayment && $hasActiveHold && ! $hasSessionStarted ? 'بررسی نوبت و پرداخت' : 'جزئیات نوبت') }}
                </h1>

                <p class="mt-2 text-sm text-gray-700">
                    وضعیت فعلی نوبت: {{ $statusLabel }}
                </p>
            </div>

            @if (session('status'))
                <div
                    class="mx-6 mt-6 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800"
                    role="status"
                >
                    {{ session('status') }}
                </div>
            @endif

            @if ($errors->any())
                <div
                    class="mx-6 mt-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm leading-7 text-red-800"
                    role="alert"
                >
                    <ul class="list-inside list-disc">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif


            <div class="space-y-6 p-6">
                @if ($isPendingPayment)
                    <div
                        class="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-7 text-amber-900"
                        role="status"
                    >
                        @if ($hasExpiredHold)
                            <p class="font-medium">
                                مهلت رزرو موقت این نوبت پایان یافته است.
                            </p>

                            <p class="mt-1">
                                این نوبت تأیید نشده و دیگر زمان جلسه را برای شما نگه نمی‌دارد.
                                برای رزرو مجدد، زمان‌های موجود را بررسی کنید.
                            </p>
                        @elseif ($hasSessionStarted)
                            <p class="font-medium">
                                زمان شروع جلسه فرا رسیده و این نوبت تأیید نشده است.
                            </p>

                            <p class="mt-1">
                                برای ثبت نوبت جدید، زمان‌های موجود را بررسی کنید.
                            </p>
                        @else
                            <p class="font-medium">
                                این نوبت به‌صورت موقت ثبت شده و هنوز تأیید نهایی نشده است.
                            </p>

                            <p class="mt-1">
                                پایان مهلت نگهداری موقت:
                                <strong>
                                    {{ \App\Support\PersianDate::format($holdExpiresAt) }}
                                    ساعت
                                    {{ $holdExpiresAt->format('H:i:s') }}
                                </strong>
                                به وقت تهران.
                            </p>

                            <p class="mt-1">
                                تأیید نهایی به پرداخت موفق یا تأیید رایگان با کد تخفیف معتبر،
                                و معتبر بودن زمان نوبت وابسته است.
                                مهلت نگهداری موقت، امکان پرداخت پس از شروع جلسه را تضمین نمی‌کند.
                            </p>
                        @endif
                    </div>
                @endif

                <div class="cbf-tracking flex items-center justify-between border-b border-gray-100 pb-4">
<span class="text-sm text-gray-500">
    کد پیگیری نوبت
</span>

                    <strong data-tracking-code dir="ltr" class="break-all font-mono text-sm text-gray-900">
                        {{ $appointment->tracking_code }}
                    </strong>
                    <button type="button" class="cbf-copy" data-copy-tracking hidden>کپی کد پیگیری</button>
                    <p class="cbf-copy-status" data-copy-status role="status" aria-live="polite"></p>

                </div>

                <div class="cbc-summary grid gap-5 sm:grid-cols-2">
                    <div>
                        <span class="block text-sm text-gray-500">
                            روان‌شناس
                        </span>

                        <strong class="mt-1 block text-gray-900">
                            {{ $appointment->psychologist->first_name }}
                            {{ $appointment->psychologist->last_name }}
                        </strong>
                    </div>

                    <div>
                        <span class="block text-sm text-gray-500">
                            وضعیت
                        </span>

                        <span
                            class="mt-1 inline-flex rounded-full px-3 py-1 text-sm font-medium {{ $statusClasses }}"
                        >
                            {{ $statusLabel }}
                        </span>
                    </div>

                    <div>
                        <span class="block text-sm text-gray-500">
                            تاریخ جلسه
                        </span>

                        <strong class="mt-1 block text-gray-900">
                            {{ PersianDate::format($startsAt) }}
                        </strong>

                        <span class="mt-1 block text-xs text-gray-500">
                            {{ $startsAt->locale('fa')->dayName }}
                        </span>
                    </div>

                    <div>
                        <span class="block text-sm text-gray-500">
                            ساعت جلسه · به وقت تهران
                        </span>

                        <strong class="mt-1 block text-gray-900">
                            {{ $startsAt->format('H:i') }}
                            تا
                            {{ $endsAt->format('H:i') }}
                        </strong>
                    </div>

                    <div>
                        <span class="block text-sm text-gray-500">
                            مدت جلسه
                        </span>

                        <strong class="mt-1 block text-gray-900">
                            {{ $appointment->duration_minutes }} دقیقه
                        </strong>
                    </div>

                    <div>
                        <span class="block text-sm text-gray-500">
                            شیوه برگزاری
                        </span>

                        <strong class="mt-1 block text-gray-900">
                            {{ $sessionType }}
                        </strong>
                    </div>
                </div>

                <section class="cbf-next" aria-labelledby="cbf-next-title">
                    <h2 id="cbf-next-title">قدم بعدی شما</h2>
                    @if ($isConfirmed)
                        <p>نوبت شما تأیید شده است. برای پیگیری جزئیات و امکانات مربوط به جلسه، به «نوبت‌های من» بروید.</p>
                        @if (! $hasSessionStarted)
                            @if ($appointment->session_type === Appointment::SESSION_TYPE_ONLINE)
                                <ul><li>پیش از جلسه، اتصال اینترنت، میکروفن و هدفون خود را بررسی کنید.</li><li>محیطی آرام و خصوصی برای گفت‌وگو انتخاب کنید.</li><li>جزئیات دسترسی به جلسه را در حساب خود بررسی کنید.</li></ul>
                            @elseif ($appointment->session_type === Appointment::SESSION_TYPE_IN_PERSON)
                                <ul><li>پیش از حرکت، نشانی و جزئیات مراجعه را بررسی کنید.</li><li>برای حضور به‌موقع برنامه‌ریزی کنید؛ ساعت نوبت به وقت تهران است.</li></ul>
                            @endif
                        @else
                            <p>زمان شروع این نوبت فرا رسیده است؛ آخرین جزئیات آن را در حساب خود بررسی کنید.</p>
                        @endif
                    @elseif ($isPendingPayment && $hasActiveHold && ! $hasSessionStarted)
                        <p>رزرو هنوز قطعی نیست. برای ادامه، فاکتور و گزینه‌های تسویهٔ همین صفحه را بررسی کنید. داشتن کد پیگیری به‌تنهایی به معنی تأیید نوبت یا پرداخت موفق نیست.</p>
                    @elseif ($isPendingPayment)
                        <p>این نوبت تأیید نشده است و امکان ادامهٔ پرداخت در این صفحه وجود ندارد. برای رزرو جدید، زمان‌های موجود را بررسی کنید.</p>
                    @elseif ($appointment->status === Appointment::STATUS_CANCELLED)
                        <p>این نوبت لغو شده است. وضعیت لغو به‌تنهایی نشان‌دهندهٔ انجام بازپرداخت نیست. برای پیگیری، کد نوبت را نگه دارید.</p>
                    @elseif ($appointment->status === Appointment::STATUS_COMPLETED)
                        <p>این جلسه تکمیل شده است. برای مرور سوابق نوبت‌ها به حساب خود بروید.</p>
                    @elseif ($appointment->status === Appointment::STATUS_NO_SHOW)
                        <p>برای این جلسه وضعیت عدم حضور ثبت شده است. این عنوان به‌تنهایی مشخص نمی‌کند عدم حضور مربوط به کدام طرف بوده یا بازپرداخت انجام شده است.</p>
                    @else
                        <p>برای پیگیری آخرین جزئیات، نوبت‌های خود را در حساب کاربری بررسی کنید.</p>
                    @endif
                    <a class="cbf-account-link" href="{{ route('client.appointments.index') }}">رفتن به نوبت‌های من ←</a>
                    <p class="cbf-privacy">کد پیگیری و جزئیات جلسه را فقط در اختیار افراد مورد اعتماد قرار دهید.</p>
                </section>

                <section class="cbc-policy" aria-labelledby="booking-policy-title">
                    <h2 id="booking-policy-title">شرایط لغو و بازپرداخت</h2>
                    <p>پیش از پرداخت، زمان جلسه و شرایط زیر را بررسی کنید. بازه‌ها نسبت به زمان شروع جلسه محاسبه می‌شوند.</p>
                    <dl>
                        <div><dt>۲۴ ساعت یا بیشتر مانده به جلسه</dt><dd>بازپرداخت ۱۰۰٪</dd></div>
                        <div><dt>از ۸ ساعت تا کمتر از ۲۴ ساعت مانده به جلسه</dt><dd>بازپرداخت ۵۰٪</dd></div>
                        <div><dt>کمتر از ۸ ساعت مانده به جلسه یا عدم حضور مراجع</dt><dd>بدون بازپرداخت</dd></div>
                        <div><dt>عدم حضور مشاور</dt><dd>بازپرداخت کامل، حداکثر طی ۷۲ ساعت کاری</dd></div>
                    </dl>
                </section>

                @include('booking._invoice')

                <div class="cbc-footer flex flex-col gap-3 border-t border-gray-200 pt-6 sm:flex-row">
                    <a
                        href="{{ route('booking.index') }}"
                        class="inline-flex min-h-11 flex-1 items-center justify-center rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                    >
                        رزرو نوبت دیگر
                    </a>

                    <a
                        href="{{ route('client.appointments.index') }}"
                        class="inline-flex min-h-11 flex-1 items-center justify-center rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                    >
                        مشاهده نوبت‌های من
                    </a>
                </div>
            </div>
        </section>
    </main>
@endsection
@push('scripts')
<script src="{{ asset('website/js/care-booking-followup.js') }}?v=1" defer></script>
@endpush
