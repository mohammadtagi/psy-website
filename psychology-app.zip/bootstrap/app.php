<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use App\Http\Middleware\EnsureUserHasRole;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'role' => EnsureUserHasRole::class,
        ]);

        $middleware->redirectGuestsTo(
            fn (Request $request): string => route('auth.login')
        );

        $middleware->validateCsrfTokens(except: [
            'payments/behpardakht/callback',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request, \Throwable $exception): bool =>
                $request->is('booking/account')
                || ($request->is('login', 'login/*', 'booking', 'booking/*')
                    ? $request->wantsJson()
                    : $request->expectsJson()),
        );

        // Includes errors raised before controllers: auth, CSRF and throttling.
        $exceptions->respond(function (\Symfony\Component\HttpFoundation\Response $response) {
            $request = request();
            if (
                ($request->is('booking/account') || $request->wantsJson())
                && $request->is('login', 'login/*', 'booking', 'booking/*')
            ) {
                $response->headers->set('Cache-Control', 'no-store');
            }

            return $response;
        });
    })->create();
